echo "Usage: $0 <parameter>"
cat "$AXP209_ETC/usage.txt"
